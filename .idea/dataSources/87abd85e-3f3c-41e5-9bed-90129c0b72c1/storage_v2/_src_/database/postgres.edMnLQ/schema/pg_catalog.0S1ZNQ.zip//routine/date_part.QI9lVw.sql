create function date_part(text, date) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

alter function date_part(text, date) owner to postgres;

